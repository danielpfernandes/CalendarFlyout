using System.ComponentModel;
using System.Net;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using CalendarFlyout.Native;
using CalendarFlyout.Services;
using Google;
using Google.Apis.Auth.OAuth2.Responses;

namespace CalendarFlyout;

public partial class MainWindow : Window
{
    private readonly CalendarClient _calendar = new();
    private readonly CancellationTokenSource _lifetime = new();
    private readonly DispatcherTimer _timer;
    private readonly ThemeService _theme;
    private bool _busy;
    private bool _stopping;
    private Task _pending = Task.CompletedTask;

    public MainWindow()
    {
        InitializeComponent();
        _theme = new ThemeService(this);
        _theme.Apply();
        SourceInitialized += (_, _) => { WindowEffects.Initialize(this); _theme.Apply(); };
        // Só consulta em intervalos enquanto o painel estiver visível.
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMinutes(1) };
        _timer.Tick += (_, _) => Run(RefreshAsync);
        UpdateButtons();
    }

    public void ShowFlyout()
    {
        if (_stopping) return;
        new WindowInteropHelper(this).EnsureHandle();
        _theme.Apply();
        WindowEffects.Place(this, false);
        Show();
        WindowEffects.Place(this, true);
        _timer.Start();
        Run(RefreshAsync);
    }

    private void Dismiss() { _timer.Stop(); Hide(); }
    private void Window_Deactivated(object? sender, EventArgs e) => Dismiss();
    private void Hide_Click(object sender, RoutedEventArgs e) => Dismiss();
    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape) { Dismiss(); e.Handled = true; }
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (!_stopping) { e.Cancel = true; Dismiss(); }
        base.OnClosing(e);
    }

    private void Connect_Click(object sender, RoutedEventArgs e) => Run(async token =>
    {
        StatusText.Text = "Conclua o login no navegador e reabra a agenda pela bandeja.";
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeout.CancelAfter(TimeSpan.FromMinutes(3));
        await _calendar.ConnectAsync(timeout.Token);
        await RefreshAsync(token);
        // Nunca rouba foco nem reabre o painel após o retorno do navegador.
    });

    private void Refresh_Click(object sender, RoutedEventArgs e) => Run(RefreshAsync);
    private void Forget_Click(object sender, RoutedEventArgs e) => Run(async _ =>
    {
        await _calendar.ForgetAsync();
        DaysList.ItemsSource = null;
        StatusText.Text = "Login removido deste computador. Conecte novamente quando quiser.";
    });

    private async Task RefreshAsync(CancellationToken token)
    {
        if (!await _calendar.RestoreAsync())
        {
            StatusText.Text = "Conecte sua conta para ver a agenda.";
            return;
        }
        StatusText.Text = "Atualizando agenda…";
        var today = DateTime.Today;
        var events = await _calendar.LoadAsync(today, token);
        if (_stopping) return;
        DaysList.ItemsSource = AgendaProjection.Build(events, today, TimeZoneInfo.Local);
        StatusText.Text = $"Atualizado às {DateTime.Now:HH:mm} · {events.Count} evento(s)";
    }

    private void Run(Func<CancellationToken, Task> operation)
    {
        if (_busy || _stopping) return;
        _pending = ExecuteAsync(operation);
    }

    private async Task ExecuteAsync(Func<CancellationToken, Task> operation)
    {
        _busy = true;
        UpdateButtons();
        try { await operation(_lifetime.Token); }
        catch (OperationCanceledException)
        {
            if (!_stopping) StatusText.Text = "Operação cancelada ou login expirado. Tente novamente.";
        }
        catch (TokenResponseException)
        {
            DaysList.ItemsSource = null;
            StatusText.Text = "O Google recusou a autorização. Use Esquecer login e conecte novamente.";
        }
        catch (GoogleApiException ex) when (ex.HttpStatusCode == HttpStatusCode.Unauthorized)
        {
            DaysList.ItemsSource = null;
            StatusText.Text = "Sua autorização expirou. Use Esquecer login e conecte novamente.";
        }
        catch (GoogleApiException ex) when (ex.HttpStatusCode == HttpStatusCode.Forbidden)
        {
            StatusText.Text = "Acesso negado: confira a API Calendar, as permissões e a quota no Google Cloud.";
        }
        catch (CryptographicException)
        {
            StatusText.Text = "Não foi possível proteger ou ler o login. Confira o perfil Windows; para remover um token inválido, use Esquecer login.";
        }
        catch (InvalidOperationException ex) { StatusText.Text = ex.Message; }
        catch (Exception)
        {
            // Não expõe tokens, respostas OAuth ou dados dos eventos em logs/mensagens.
            StatusText.Text = "Não foi possível atualizar. Confira a conexão e client_secret.json. Os dados exibidos podem estar desatualizados.";
        }
        finally
        {
            _busy = false;
            if (!_stopping) UpdateButtons();
        }
    }

    private void UpdateButtons()
    {
        ConnectButton.IsEnabled = !_busy && !_calendar.IsConnected;
        ConnectButton.Visibility = _calendar.IsConnected ? Visibility.Collapsed : Visibility.Visible;
        RefreshButton.IsEnabled = !_busy && _calendar.IsConnected;
        // Disponível mesmo com um token corrompido ou configuração ausente.
        ForgetButton.IsEnabled = !_busy;
    }

    public void Stop()
    {
        if (_stopping) return;
        _stopping = true;
        _timer.Stop();
        _theme.Dispose();
        _lifetime.Cancel();
        // Evita Dispose concorrente com uma requisição HTTP em andamento.
        if (_pending.IsCompleted) { _calendar.Dispose(); _lifetime.Dispose(); }
        else _ = _pending.ContinueWith(_ => { _calendar.Dispose(); _lifetime.Dispose(); }, TaskScheduler.Default);
    }
}
