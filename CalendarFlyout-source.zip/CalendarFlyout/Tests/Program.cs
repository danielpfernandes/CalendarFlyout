using System.IO;
using CalendarFlyout.Services;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Calendar.v3.Data;

var passed = 0;
void Check(bool condition, string name)
{
    if (!condition) throw new Exception("FAIL: " + name);
    Console.WriteLine("PASS: " + name);
    passed++;
}

var today = new DateTime(2026, 9, 15);
Event Timed(string title, string start, string end) => new()
{
    Summary = title,
    Start = new EventDateTime { DateTimeDateTimeOffset = DateTimeOffset.Parse(start) },
    End = new EventDateTime { DateTimeDateTimeOffset = DateTimeOffset.Parse(end) }
};
var zone = TimeZoneInfo.CreateCustomTimeZone("Test -03", TimeSpan.FromHours(-3), "Test -03", "Test -03");
var entries = new List<Event>
{
    new() { Summary = "Férias", Start = new() { Date = "2026-09-14" }, End = new() { Date = "2026-09-17" } },
    Timed("Virada", "2026-09-16T02:30:00Z", "2026-09-16T03:30:00Z"),
    Timed("À meia-noite", "2026-09-15T22:00:00-03:00", "2026-09-16T00:00:00-03:00"),
    Timed("Último dia", "2026-09-18T23:00:00-03:00", "2026-09-19T00:00:00-03:00"),
    Timed("Fora", "2026-09-19T00:00:00-03:00", "2026-09-19T01:00:00-03:00"),
    new() { Summary = "Cancelado", Status = "cancelled", Start = new() { Date = "2026-09-15" }, End = new() { Date = "2026-09-16" } },
    Timed("", "2026-09-15T10:00:00-03:00", "2026-09-15T11:00:00-03:00")
};
var days = AgendaProjection.Build(entries, today, zone);
Check(days.Count == 4, "Hoje e próximos três dias");
Check(days[0].Events[0].Title == "Férias", "Dia inteiro antes dos eventos com horário");
Check(days[1].Events.Any(x => x.Title == "Férias") && !days[2].Events.Any(x => x.Title == "Férias"), "Fim exclusivo de all-day");
Check(days[0].Events.Any(x => x.Title == "Virada") && days[1].Events.Any(x => x.Title == "Virada"), "Evento atravessando meia-noite em dois dias");
Check(days[0].Events.Single(x => x.Title == "Virada").TimeLabel == "15/09 23:30 – 16/09 00:30", "Conversão UTC para horário local");
Check(!days[1].Events.Any(x => x.Title == "À meia-noite"), "Fim à meia-noite não ocupa dia seguinte");
Check(days[3].Events.Any(x => x.Title == "Último dia") && days.All(d => d.Events.All(x => x.Title != "Fora")), "Limites da janela de quatro dias");
Check(days.All(d => d.Events.All(x => x.Title != "Cancelado")), "Eventos cancelados excluídos");
Check(days[0].Events.Any(x => x.Title == "(Sem título)"), "Título ausente");
Check(days[2].EmptyVisibility == System.Windows.Visibility.Visible, "Dia vazio");
var eastern = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
Check((AgendaProjection.LocalBoundary(new DateTime(2026, 3, 9), eastern) - AgendaProjection.LocalBoundary(new DateTime(2026, 3, 8), eastern)).TotalHours == 23, "Limites respeitam mudança de horário de verão");

var folder = Path.GetFullPath(args.Length > 0 ? args[0] : Path.Combine(Path.GetTempPath(), "CalendarFlyout-tests-" + Guid.NewGuid().ToString("N")));
Directory.CreateDirectory(folder);
var store = new EncryptedDataStore(folder);
const string key = "roundtrip";
var token = new TokenResponse { AccessToken = "fake-access-secret", RefreshToken = "fake-refresh-secret", TokenType = "Bearer" };
await store.StoreAsync(key, token);
var bytes = await File.ReadAllBytesAsync(Directory.GetFiles(folder, "*.bin").Single());
Check(!System.Text.Encoding.UTF8.GetString(bytes).Contains("fake-access-secret"), "Token não persistido em texto puro");
var restored = await new EncryptedDataStore(folder).GetAsync<TokenResponse>(key);
Check(restored.AccessToken == token.AccessToken && restored.RefreshToken == token.RefreshToken, "DPAPI recupera access e refresh token em nova instância");
await store.StoreAsync(key, new TokenResponse { AccessToken = "updated" });
Check((await store.GetAsync<TokenResponse>(key)).AccessToken == "updated", "Atualização atômica do token");
await store.DeleteAsync<TokenResponse>(key);
Check(await store.GetAsync<TokenResponse>(key) is null, "Exclusão do token");
await store.StoreAsync(key, token);
await store.ClearAsync();
Check(await store.GetAsync<TokenResponse>(key) is null, "Limpeza do login");
Console.WriteLine($"{passed} verificações passaram.");
