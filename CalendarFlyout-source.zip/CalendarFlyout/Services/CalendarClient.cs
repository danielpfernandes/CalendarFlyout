using System.Text.Json;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Calendar.v3;
using Google.Apis.Calendar.v3.Data;
using Google.Apis.Services;

namespace CalendarFlyout.Services;

public sealed class CalendarClient : IDisposable
{
    private const string UserKey = "default-user";
    private static readonly string[] Scopes = { CalendarService.Scope.CalendarEventsReadonly };
    private readonly EncryptedDataStore _store = new(Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CalendarFlyout", "Tokens"));
    private GoogleAuthorizationCodeFlow? _flow;
    private CalendarService? _service;
    public bool IsConnected => _service is not null;

    private static ClientSecrets LoadSecrets()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "client_secret.json");
        if (!File.Exists(path))
            throw new InvalidOperationException("Coloque client_secret.json (OAuth para aplicativo de computador) ao lado do executável.");
        using var document = JsonDocument.Parse(File.ReadAllText(path));
        if (!document.RootElement.TryGetProperty("installed", out var installed))
            throw new InvalidOperationException("Use uma credencial OAuth do tipo Aplicativo para computador.");
        return new ClientSecrets
        {
            ClientId = installed.GetProperty("client_id").GetString(),
            ClientSecret = installed.GetProperty("client_secret").GetString()
        };
    }

    public async Task<bool> RestoreAsync()
    {
        if (IsConnected) return true;
        var token = await _store.GetAsync<TokenResponse>(UserKey);
        if (token is null) return false;
        _flow?.Dispose();
        _flow = new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
        {
            ClientSecrets = LoadSecrets(), Scopes = Scopes, DataStore = _store
        });
        SetCredential(new UserCredential(_flow, UserKey, token));
        return true;
    }

    public async Task ConnectAsync(CancellationToken cancellationToken)
    {
        // Navegador padrão + callback loopback gerenciados pela biblioteca oficial.
        var credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(
            LoadSecrets(), Scopes, UserKey, cancellationToken, _store);
        _service?.Dispose();
        _service = null;
        _flow?.Dispose();
        _flow = credential.Flow as GoogleAuthorizationCodeFlow;
        SetCredential(credential);
    }

    private void SetCredential(UserCredential credential)
    {
        _service = new CalendarService(new BaseClientService.Initializer
        {
            HttpClientInitializer = credential, ApplicationName = "CalendarFlyout"
        });
        _service.HttpClient.Timeout = TimeSpan.FromSeconds(30);
    }

    public async Task<List<Event>> LoadAsync(DateTime firstDay, CancellationToken cancellationToken)
    {
        var service = _service ?? throw new InvalidOperationException("Conecte sua conta Google.");
        var start = AgendaProjection.LocalBoundary(firstDay, TimeZoneInfo.Local);
        var end = AgendaProjection.LocalBoundary(firstDay.AddDays(4), TimeZoneInfo.Local);
        var events = new List<Event>();
        string? page = null;
        do
        {
            var request = service.Events.List("primary");
            request.TimeMinDateTimeOffset = start;
            request.TimeMaxDateTimeOffset = end;
            request.TimeZone = "UTC"; // Datas com horário serão convertidas para o fuso do Windows na projeção.
            request.SingleEvents = true;
            request.ShowDeleted = false;
            request.OrderBy = EventsResource.ListRequest.OrderByEnum.StartTime;
            request.MaxResults = 2500;
            request.PageToken = page;
            var response = await request.ExecuteAsync(cancellationToken);
            if (response.Items is not null) events.AddRange(response.Items);
            page = response.NextPageToken;
        } while (!string.IsNullOrEmpty(page));
        return events;
    }

    public async Task ForgetAsync()
    {
        Dispose();
        await _store.ClearAsync();
    }

    public void Dispose()
    {
        _service?.Dispose(); _service = null;
        _flow?.Dispose(); _flow = null;
    }
}
